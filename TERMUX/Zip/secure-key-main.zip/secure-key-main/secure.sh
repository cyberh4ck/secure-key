# creating a menu with the following options
figlet " SECURE KEY " | lolcat
sleep 5
echo -e "\e[1;33m[ALL PRODUCT KEYS]   \e[m"
sleep 3
echo -e "\e[1;33m[TEAM CYBERH4CKS]\e[m"
sleep 3
echo -e "\e[1;33m[CODED BY DARKHEAVEN]   \e[m"
sleep 3
echo -e "\e[1;32m[1] VIMWARE WORKSTATION  \e[0m"
sleep 3
echo -e "\e[1;32m[2] Windows 10 Enterprise Key \e[0m"
sleep 3
echo -e "\e[1;32m[3] Windows 10 Home Country Specific \e[0m"
sleep 3
echo -e "\e[1;32m[4] Windows 10 Education N \e[0m"
sleep 3
echo -e "\e[1;32m[5] Windows 10 Enterprise Evaluation \e[0m"
sleep 3
echo -e "\e[1;32m[6] Windows 10 Home + Office 2016 Professional Key \e[0m"
sleep 3
echo -e "\e[1;32m[7] Windows 10 Pro + Office 2016 Professional Key \e[0m"
sleep 3
echo -e "\e[1;32m[8] Windows 10 Education Key   \e[0m"
sleep 3
echo -e "\e[1;32m[9] Windows 10 Enterprise key \e[0m"
sleep 3
echo -e "\e[1;32m[10] Windows 10 Pro N  \e[0m"
sleep 3
echo -e "\e[1;32m[11] Windows 10 Pro Key  \e[0m"
sleep 3
echo -e "\e[1;32m[12] Windows 10 Home  \e[0m"
echo -e "\e[1;31m[13]  Exit From Menu  \e[0m"
echo -e "\e[1;34m[*]  Enter Your Choice:  \e[0m"


# Running a forever loop using while statement
# This loop will run untill select the exit option 
# User will be asked to select option again and again
while :
do

# reading choice
read choice

# case statement is used to compare one value with the multiple cases.
case $choice in
  # Pattern 1
  1)   clear
       figlet " CYBERH4CKS  " | lolcat      
       sleep 2
       echo -e "\e[1;36m [LOADING 4 KEYS]  \e[0m"
       sleep 3
       echo -e "\e[1;36m [KEYS] ZF3R0-FHED2-M80TY-8QYGC-NPKYF  \e[0m"
       sleep 3
       echo -e "\e[1;36m [KEYS] YF390-0HF8P-M81RQ-2DXQE-M2UT6  \e[0m"
       sleep 3
       echo -e "\e[1;36m [KEYS] ZF71R-DMX85-08DQY-8YMNC-PPHV8 \e[0m"
       sleep 3
       echo -e "\e[1;36m [KEYS] ZF3R0-FHED2-M80TY-8QYGC-NPKYF \e[0m"
       sleep 1000000000000000
       echo "Exit. ";;
  # Pattern 2
  2)  clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] 84NGF-MHBT6-FXBX8-QWJK7-DRR8H \e[0m"
       sleep 10000000000
        echo "Exit. ";;
  # Pattern 3
  3) clear                                
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] YYVX9-NTFWV-6MDM3-9PT4T-4M68B \e[0m"
       sleep 10000000000
        echo "Exit. ";;         
   # Pattern 4
   4) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] XGVPP-NMH47-7TTHJ-W3FW7-8HV2C \e[0m"
       sleep 10000000000
        echo "Exit. ";;
    # Pattern 5
   5) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] NPPR9-FWDCX-D2C8J-H872K-2YT43 \e[0m"
       sleep 10000000000
        echo "Exit. ";; 
   # Pattern 6
   6) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] MNXKQ-WY2CT-JWBJ2-T68TQ-YBH2V \e[0m"
       sleep 10000000000
        echo "Exit. ";;
     # Pattern 7
    7) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] MNXKQ-WY2CT-JWBJ2-T68TQ-YBH2V \e[0m"
       sleep 10000000000
        echo "Exit. ";; 
     # Pattern 8
    8) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] QFFDN-GRT3P-VKWWX-X7T3R-8B639 \e[0m"
       sleep 10000000000
        echo "Exit. ";;
     # Pattern 9
    9) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] 84NGF-MHBT6-FXBX8-QWJK7-DRR8H \e[0m"
       sleep 10000000000
        echo "Exit. ";; 
     # Pattern 10
    10) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] 2F77B-TNFGY-69QQF-B8YKP-D69TJ \e[0m"
       sleep 10000000000
        echo "Exit. ";;
     # Pattern 11
    11) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] VK7JG-NPHTM-C97JM-9MPGT-3V66T \e[0m"
       sleep 10000000000
        echo "Exit. ";;
    # Pattern 12
    12) clear
       figlet " CYBERH4CKS  " | lolcat
       sleep 4
       echo -e "\e[1;36m [KEYS] WNMTR-4C88C-JK8YV-HQ7T2-76DF9 \e[0m"
       sleep 10000000000
        echo "Exit. ";; 
      #Pattern 13
   13) echo -e "\e[1;31mOKAY GOODBYE... \e[0m"
      exit;;
  # Default Pattern
  *) echo -e "\e[1;31m[Comment Not Found]  \e[0m" ;;
  
esac 
done


